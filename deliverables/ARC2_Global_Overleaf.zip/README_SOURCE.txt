Anonymous LNCS manuscript-source draft.
Select main.tex as the main document on Overleaf.
Local build: pdflatex main; bibtex main; pdflatex main; pdflatex main.
Prebuilt vector figures are included. mechanism.tex is editable TikZ.
The complete descriptive TREC Recall table is generated/trec_recall.tex; the main paper also plots all its values.
The MiniLM matched-target controls are integrated into Figure 3 and Results; GCPA is cited in related work.
This is the manuscript source, not the full research-reproduction artifact.
Internal author paths, review logs, server records and raw research bundles are excluded.
